#!/bin/bash
set -e

# Por defecto el access.log de Apache es propiedad de root con permisos 640
# (grupo adm), lo que impide que el proceso php (www-data) lo pueda leer
# mediante el include() vulnerable. Lo pre-creamos con permisos 644 para
# que la fase de log poisoning funcione de forma fiable en el CTF.
touch /var/log/apache2/access.log
chmod 644 /var/log/apache2/access.log

exec apache2-foreground
