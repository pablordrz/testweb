<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Portal Corporativo</title>
</head>
<body>
    <h1>Bienvenido al portal</h1>
    <p>Navega usando <code>?page=welcome.php</code></p>
</body>
</html>
